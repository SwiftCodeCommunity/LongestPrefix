/*
 we first sort the elements and pick the least-count word for loop count.
 We then use swift's allSatisfy method to check if prefix exists in all items in array.
*/

func getLongestPrefix(words: [String]) -> String {
    let validWords = words
        .sorted()
    guard !validWords.isEmpty else {
        return ""
    }
    let minimumWord = words[0]
    var prefix = ""
    for index in 0..<minimumWord.count {
        let nextPrefix = minimumWord.prefix(index + 1)
        if !(validWords.allSatisfy { $0.hasPrefix(nextPrefix) }) {
            prefix = String(nextPrefix.dropLast())
            break
        }
        if index == minimumWord.count - 1 {
            return minimumWord
        }
    }
    return prefix
}

func getLongestPrefixUsingTwoWordApproach(words: [String]) -> String {
    let validWords = words.sorted()
    guard !validWords.isEmpty, validWords.count > 1 else {
        return ""
    }
    let firstWord = words[0]
    let secondWord = words[1]
    for index in 0..<firstWord.count {
        if firstWord.prefix(index + 1) != secondWord.prefix(index + 1) {
            return String(firstWord.prefix(index))
        }
        if index == firstWord.count - 1 {
            return firstWord
        }
    }
    return ""
}



let words: [String] = ["floor", "floor", "floor"]
print(getLongestPrefix(words: words))
print(getLongestPrefixUsingTwoWordApproach(words: words))
