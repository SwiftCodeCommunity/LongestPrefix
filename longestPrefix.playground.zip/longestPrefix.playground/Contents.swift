/*
 we first sort the elements and pick the least-count word for loop count.
 We then use swift's allSatisfy method to check if prefix exists in all items in array.
*/

func getLongestPrefix(words: [String]) -> String {
    let validWords = words
        .sorted()
    guard !validWords.isEmpty else {
        return ""
    }
    let minimumWord = words[0]
    var prefix = ""
    for index in 0..<minimumWord.count {
        let nextPrefix = minimumWord.prefix(index + 1)
        if !(validWords.allSatisfy { $0.hasPrefix(nextPrefix) }) {
            prefix = String(nextPrefix.dropLast())
            break
        }
    }
    return prefix
}


let words: [String] = ["floor", "flower", "float"]
print(getLongestPrefix(words: words))
